<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Página con Bootstrap y Tabla</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">MOSCU-PICTURES</a>
      <a class="btn btn-primary ml-auto" href="index.php">Nuevo</a>
    </div>
  </nav>

  <div class="container mt-3">
    <div class="input-group mb-3">
      <input type="text" class="form-control" placeholder="Buscar" id="searchInput">
      <div class="input-group-append">
        <button class="btn btn-outline-secondary" type="button" id="searchButton">Buscar</button>
      </div>
    </div>
  </div>

  <div class="container mt-3">
    <h2>Lista de fotógrafos</h2>
    <table class="table table-bordered" id="clientesTable">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Nombre</th>
          <th scope="col">Apellidos</th>
          <th scope="col">Correo electrónico</th>
          <th scope="col">Teléfono</th>
          <th scope="col">Dirección</th>
          <th scope="col">Acciones</th>
        </tr>
      </thead>
      <tbody>
        </tbody>
    </table>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    const fotografoTable = document.getElementById('clientesTable');
    const searchButton = document.getElementById('searchButton');
    const searchInput = document.getElementById('searchInput');

    // Function to populate table with data from database
    function getclientes(searchTerm = '') {
      const xhr = new XMLHttpRequest();
      xhr.open('GET', 'get_clientes.php?search=' + searchTerm);
      xhr.onload = function() {
        if (xhr.status === 200) {
          const data = JSON.parse(xhr.responseText);
          fotografoTable.innerHTML = ''; // Clear existing data
          let tableBody = '';
          data.forEach((clientes, index) => {
            tableBody += `
              <tr>
                <td>${index + 1}</td>
                <td>${clientes.nombre}</td>
                <td>${clientes.apellidos}</td>
                <td>${clientes.correoElectronico}</td>
                <td>${clientes.telefono}</td>
                <td>${clientes.direccion}</td>
                <td>
                  <button class="btn btn-sm btn-primary">Actualizar</button>
                  <button class="btn btn-sm btn-danger">Borrar</button>
                </td>
              </tr>
            `;
          });
          clientesTable.innerHTML = tableBody;
        } else {
          console.error('Error fetching data:', xhr.statusText);
        }
      };
      xhr.send();
    }

    // Get data on page load
    getclientes();

    // Implement search functionality (Optional)
    searchButton.addEventListener('click', () => {
      const searchTerm = searchInput.value.trim();
      getclientes(searchTerm);
    });

  </script>
</body>
</html>
