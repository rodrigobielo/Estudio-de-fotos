<?php
include 'conexion.php'; // Archivo de conexión a la base de datos
include 'ClientesModel.php'; // Modelo para manejar la lógica de inserción


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $clientes = new stdClass();
    $clientes->nombre = $_POST['nombre'];
    $clientes->apellidos = $_POST['apellidos'];
    $clientes->correoElectronico = $_POST['correoElectronico'];
    $clientes->telefono = $_POST['telefono'];
    $clientes->direccion = $_POST['direccion'];

    $model = new ClientesModel($connection); // Crear una instancia del modelo
    $result = $model->insertCliente($clientes); // Llamar al método para insertar el cliente

    if ($result) {
        echo "Fotógrafo registrado exitosamente!";
    } else {
        echo "Error al registrar fotógrafo.";
    }
}
?>
