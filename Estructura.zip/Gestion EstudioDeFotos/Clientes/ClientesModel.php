<?php
class ClientesModel {
    private $connection;

    // Constructor que recibe la conexión a la base de datos
    public function __construct($connection) {
        $this->connection = $connection;
    }

    // Método para insertar un fotógrafo en la base de datos
    public function insertCliente($clientes) {
        $nombre = $clientes->nombre;
        $apellidos = $clientes->apellidos;
        $correoElectronico = $clientes->correoElectronico;
        $telefono = $clientes->telefono;
        $direccion = $clientes->direccion;

        $sql = "INSERT INTO clientes (nombre, apellidos, correoElectronico, telefono, direccion) VALUES ('$nombre', '$apellidos', '$correoElectronico', '$telefono', '$direccion')";

        if ($this->connection->query($sql) === TRUE) {
            return true; // Si la inserción fue exitosa
        } else {
            return false; // Si hubo un error en la inserción
        }
    }
}
?>
